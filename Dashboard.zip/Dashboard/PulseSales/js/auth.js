/* Supabase Auth login, signup, logout and dashboard route protection. */
(function () {
  'use strict';
  const auth = {
    client() { return window.PulseSalesSupabase && window.PulseSalesSupabase.client; },
    async signIn(email, password) { return this.client().auth.signInWithPassword({ email, password }); },
    async signUp(email, password, metadata) { return this.client().auth.signUp({ email, password, options: { data: metadata || {} } }); },
    async resetPassword(email) { return this.client().auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}${window.location.pathname}` }); },
    async signOut() { return this.client().auth.signOut(); },
    async session() { return this.client() ? (await this.client().auth.getSession()).data.session : null; },
    async requireSession() {
      const session = await this.session();
      if (!session) { window.location.replace('./index.html'); return null; }
      return session;
    }
  };
  window.PulseSalesAuth = auth;
  if (document.getElementById('loginForm') && auth.client()) {
    auth.session().then(session => {
      if (session) window.location.replace('./dashboard.html');
    }).catch(() => {});
  }
})();
