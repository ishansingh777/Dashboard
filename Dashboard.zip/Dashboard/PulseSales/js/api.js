/* All database access lives here. UI code consumes normalized dashboard records. */
(function () {
  'use strict';
  const api = {
    async loadDashboardData() {
      const client = window.PulseSalesSupabase && window.PulseSalesSupabase.client;
      if (!client) throw new Error('Supabase is not configured. Add the publishable key in js/config.js.');
      
      console.log("Supabase Connected");

      const { data: orders, error: orderError } = await client
        .from("orders")
        .select(`
            order_no,
            order_date_time,
            user_id,
            product_id,
            amount,
            discount_amount,
            created_by
        `);
      
      console.log("ORDERS:", orders);
      console.log("ORDER ERROR:", orderError);

      const { data: users, error: userError } = await client
        .from("users")
        .select(`
            user_id,
            name,
            country_code,
            mobile,
            user_role,
            created_dateTime
        `);

      console.log("USERS:", users);
      console.log("USER ERROR:", userError);

      const { data: products, error: productError } = await client
        .from("products")
        .select(`
            prod_id,
            productName,
            amount,
            validity,
            data_limit
        `);

      console.log("PRODUCTS:", products);
      console.log("PRODUCT ERROR:", productError);

      console.log("Orders rows:", orders ? orders.length : 0);
      console.log("Users rows:", users ? users.length : 0);
      console.log("Products rows:", products ? products.length : 0);

      if (orders && orders.length > 0) {
        console.log("First order object:", orders[0]);
      }

      const lastError = orderError || userError || productError;
      if (lastError) {
        console.log("Last error:", lastError.message);
        window.DebugPanelData = { 
          connected: 'YES', 
          ordersLoaded: orders ? orders.length : 0, 
          usersLoaded: users ? users.length : 0, 
          productsLoaded: products ? products.length : 0, 
          lastSync: new Date().toLocaleTimeString(), 
          lastError: lastError.message 
        };
        this.updateDebugPanel();
        throw lastError; // Do not catch silently
      }

      window.DebugPanelData = {
        connected: 'YES',
        ordersLoaded: orders ? orders.length : 0,
        usersLoaded: users ? users.length : 0,
        productsLoaded: products ? products.length : 0,
        lastSync: new Date().toLocaleTimeString(),
        lastError: ''
      };
      
      this.updateDebugPanel();

      const productMap = new Map((products || []).map(p => [p.prod_id, p]));
      return {
        sales: (orders || []).map(row => normalizeOrder(row, productMap)),
        customers: (users || []).map(normalizeCustomer),
        products: (products || []).map(normalizeProduct),
        users: []
      };
    },
    updateDebugPanel() {
      let panel = document.getElementById('debug-panel');
      if (!panel) {
        panel = document.createElement('div');
        panel.id = 'debug-panel';
        panel.style.position = 'fixed';
        panel.style.bottom = '10px';
        panel.style.right = '10px';
        panel.style.backgroundColor = 'rgba(0,0,0,0.8)';
        panel.style.color = 'lime';
        panel.style.padding = '10px';
        panel.style.fontFamily = 'monospace';
        panel.style.fontSize = '12px';
        panel.style.zIndex = '9999';
        panel.style.borderRadius = '5px';
        panel.style.maxWidth = '300px';
        document.body.appendChild(panel);
      }
      const d = window.DebugPanelData || {};
      panel.innerHTML = `
        <strong>DEBUG PANEL</strong><br/>
        Supabase Connected: ${d.connected || 'NO'}<br/>
        Orders Loaded: ${d.ordersLoaded !== undefined ? d.ordersLoaded : 'error'}<br/>
        Users Loaded: ${d.usersLoaded !== undefined ? d.usersLoaded : 'error'}<br/>
        Products Loaded: ${d.productsLoaded !== undefined ? d.productsLoaded : 'error'}<br/>
        Last Sync: ${d.lastSync || '-'}<br/>
        Last Error: <span style="color:red">${d.lastError || 'None'}</span>
      `;
    },
    subscribe(onChange, onStatus) {
      const client = window.PulseSalesSupabase && window.PulseSalesSupabase.client;
      if (!client) return null;
      return client.channel('pulsesales-live')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, onChange)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, onChange)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, onChange)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'destinations' }, onChange)
        .subscribe(status => { if (onStatus) onStatus(status); });
    }
  };
  function value(row, camel, snake) { return row[camel] !== undefined ? row[camel] : row[snake]; }
  function dateValue(raw) {
    if (!raw) return '';
    const match = String(raw).match(/^(\d{2})-(\d{2})-(\d{4})/);
    return match ? `${match[3]}-${match[2]}-${match[1]}` : String(raw).slice(0, 10);
  }
  function normalizeOrder(row, productMap) {
    return {
      id: row.order_no,
      customerId: row.user_id,
      productId: row.product_id,
      date: dateValue(row.order_date_time),
      quantity: 1,
      amount: Number(row.amount || 0),
      discount: Number(row.discount_amount || 0),
      netAmount: Number(row.amount || 0) - Number(row.discount_amount || 0),
    };
  }
  function normalizeCustomer(row) {
    return {
      id: row.user_id,
      name: (row.name || '').trim() || 'Unnamed customer',
      email: row.mobile ? `+${row.country_code || ''} ${row.mobile}` : '—',
      city: '—',
      joinDate: dateValue(row.created_dateTime),
      role: row.user_role
    };
  }
  function normalizeProduct(row) {
    return {
      id: row.prod_id,
      name: row.productName || `Product ${row.prod_id}`,
      price: Number(row.amount || 0),
      validity: row.validity,
      data_limit: row.data_limit
    };
  }
  window.PulseSalesApi = api;
})();
