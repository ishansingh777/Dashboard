/* One shared Supabase client for the whole application. */
(function () {
  'use strict';
  if (!window.supabase || !SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY || SUPABASE_PUBLISHABLE_KEY.startsWith('REPLACE_')) {
    window.PulseSalesSupabase = { client: null, configured: false };
    return;
  }
  window.PulseSalesSupabase = {
    client: window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY),
    configured: true
  };
})();

