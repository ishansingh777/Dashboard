/* ============================================================
   PulseSales — utils.js
   Shared helpers: currency, dates, formatting, calculations
   ============================================================ */
(function (global) {
  'use strict';

  const Utils = {
    /** Format a number as US Dollars. */
    currency(value, opts) {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 2,
        ...(opts || {})
      }).format(Number(value) || 0);
    },

    /** Compact number for counts. */
    number(value) {
      const v = Number(value) || 0;
      if (Math.abs(v) >= 1e7) return (v / 1e7).toFixed(2) + ' Cr';
      if (Math.abs(v) >= 1e5) return (v / 1e5).toFixed(2) + ' L';
      if (Math.abs(v) >= 1e3) return (v / 1e3).toFixed(1) + 'K';
      return String(Math.round(v));
    },

    /** Format a YYYY-MM-DD string into a readable date. */
    formatDate(dateStr, opts) {
      if (!dateStr) return '—';
      const d = new Date(dateStr + 'T00:00:00');
      if (isNaN(d.getTime())) return dateStr;
      const o = Object.assign({ month: 'short', day: 'numeric', year: 'numeric' }, opts || {});
      return d.toLocaleDateString('en-IN', o);
    },

    /** Abbreviated date (e.g. "12 Aug"). */
    shortDate(dateStr) {
      if (!dateStr) return '';
      const d = new Date(dateStr + 'T00:00:00');
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    },

    /** Parse YYYY-MM-DD to a local Date at midnight. */
    parseDate(dateStr) {
      return new Date(dateStr + 'T00:00:00');
    },

    /** Today's date as YYYY-MM-DD. */
    todayStr() {
      const d = new Date();
      return d.toISOString().slice(0, 10);
    },

    /** Add days to a YYYY-MM-DD string. */
    addDays(dateStr, days) {
      const d = this.parseDate(dateStr);
      d.setDate(d.getDate() + days);
      return d.toISOString().slice(0, 10);
    },

    /** Compute the date range boundaries for a given range key. */
    getRange(key) {
      const now = new Date();
      const today = this.todayStr();
      let start, end = today, label;

      switch (key) {
        case 'today':
          start = today;
          label = 'Today · ' + this.formatDate(today);
          break;
        case '7days':
          start = this.addDays(today, -6);
          label = 'Last 7 days';
          break;
        case '30days':
          start = this.addDays(today, -29);
          label = 'Last 30 days';
          break;
        case 'month': {
          const d = new Date(now.getFullYear(), now.getMonth(), 1);
          start = d.toISOString().slice(0, 10);
          label = 'This month · ' + d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
          break;
        }
        case 'year':
          start = now.getFullYear() + '-01-01';
          label = 'This year · ' + now.getFullYear();
          break;
        default:
          start = '2025-08-01';
          label = 'All time';
      }
      return { start, end, label };
    },

    /** Sum a numeric field across objects. */
    sum(arr, field) {
      return arr.reduce((a, b) => a + (Number(b[field]) || 0), 0);
    },

    /** Animate a number from 0 to target inside an element. */
    animateNumber(el, target, formatter, duration) {
      const fmt = formatter || (v => Utils.number(v));
      const dur = duration || 900;
      const startTime = performance.now();
      const from = 0;
      function tick(now) {
        const p = Math.min((now - startTime) / dur, 1);
        const eased = 1 - Math.pow(1 - p, 3); // easeOutCubic
        el.textContent = fmt(from + (target - from) * eased);
        if (p < 1) requestAnimationFrame(tick);
        else el.textContent = fmt(target);
      }
      requestAnimationFrame(tick);
    },

    /** Escape HTML to avoid injection. */
    escapeHtml(str) {
      return String(str == null ? '' : str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '<')
        .replace(/>/g, '>')
        .replace(/"/g, '"')
        .replace(/'/g, '&#39;');
    },

    /** Deterministic color from a string (for avatars). */
    colorFromString(str) {
      const colors = ['#6366f1', '#22d3ee', '#a78bfa', '#22c55e', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6'];
      let h = 0;
      for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) & 0xffffff;
      return colors[h % colors.length];
    },

    /** Initials from a name. */
    initials(name) {
      return String(name || '?').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
    },

    /** Debounce a function call. */
    debounce(fn, wait) {
      let t;
      return function (...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait || 250);
      };
    },

    /** Show a toast notification. */
    toast(message, type, ms) {
      const wrap = document.getElementById('toastWrap');
      if (!wrap) return;
      const el = document.createElement('div');
      el.className = 'toast ' + (type || 'info');
      el.textContent = message;
      wrap.appendChild(el);
      setTimeout(() => {
        el.classList.add('hide');
        setTimeout(() => el.remove(), 320);
      }, ms || 2600);
    },

    /** Percentage change between two values. */
    pctChange(current, previous) {
      if (!previous) return null;
      return ((current - previous) / previous) * 100;
    },

    /** Group an array by a key function -> Map. */
    groupBy(arr, keyFn) {
      const map = new Map();
      arr.forEach(item => {
        const k = keyFn(item);
        if (!map.has(k)) map.set(k, []);
        map.get(k).push(item);
      });
      return map;
    }
  };

  global.Utils = Utils;
})(window);
