/* ============================================================
   PulseSales — charts.js
   Chart.js creation & updates for all dashboard charts.
   ============================================================ */
(function (global) {
  'use strict';

  const charts = {};

  /* ---------- Chart.js defaults (theme-aware) ---------- */
  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }
  function themePalette() {
    const dark = document.documentElement.getAttribute('data-theme') !== 'light';
    return {
      grid: cssVar('--grid') || (dark ? 'rgba(255,255,255,0.06)' : 'rgba(30,41,70,0.08)'),
      ticks: cssVar('--text-3') || (dark ? '#8b93a7' : '#8b93a7'),
      border: cssVar('--border') || 'rgba(255,255,255,0.08)'
    };
  }

  Chart.defaults.font.family = "'Inter', sans-serif";
  Chart.defaults.color = themePalette().ticks;
  Chart.defaults.borderColor = themePalette().grid;
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.boxWidth = 8;
  Chart.defaults.plugins.legend.labels.boxHeight = 8;
  Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(13,15,22,0.92)';
  Chart.defaults.plugins.tooltip.padding = 12;
  Chart.defaults.plugins.tooltip.cornerRadius = 10;
  Chart.defaults.plugins.tooltip.titleFont = { weight: '700', size: 13 };
  Chart.defaults.plugins.tooltip.bodyFont = { size: 12.5 };
  Chart.defaults.plugins.tooltip.displayColors = true;
  Chart.defaults.plugins.tooltip.boxPadding = 4;

  const GRADIENT = ctx => {
    const g = ctx.createLinearGradient(0, 0, 0, 260);
    g.addColorStop(0, 'rgba(99,102,241,0.35)');
    g.addColorStop(1, 'rgba(99,102,241,0)');
    return g;
  };

  /** Money axis tick formatter. */
  function moneyTick(value) {
    return Utils.currency(value);
  }

  /* ================= 1. Revenue Trend (line, dual series) ================= */
  function createRevenueChart(canvas) {
    const ctx = canvas.getContext('2d');
    charts.revenue = new Chart(ctx, {
      type: 'line',
      data: { labels: [], datasets: [
        { label: 'Revenue', data: [], borderColor: '#6366f1', backgroundColor: GRADIENT(ctx), fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 0, pointHoverRadius: 5, pointBackgroundColor: '#6366f1' },
        { label: 'Orders', data: [], borderColor: '#22d3ee', backgroundColor: 'transparent', fill: false, tension: 0.4, borderWidth: 2, borderDash: [6, 4], pointRadius: 0, pointHoverRadius: 5, pointBackgroundColor: '#22d3ee', yAxisID: 'yOrders' }
      ]},
      options: {
        responsive: true, maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => c.dataset.label + ': ' + (c.dataset.yAxisID === 'yOrders' ? Utils.number(c.parsed.y) : Utils.currency(c.parsed.y)) } } },
        scales: {
          y: { beginAtZero: true, grid: { color: themePalette().grid }, ticks: { callback: moneyTick } },
          yOrders: { position: 'right', beginAtZero: true, grid: { drawOnChartArea: false }, ticks: { precision: 0 } }
        }
      }
    });
  }

  /* ================= 2. Category Sales (bar) ================= */
  function createCategoryChart(canvas) {
    const ctx = canvas.getContext('2d');
    const base = ctx.createLinearGradient(0, 0, 0, 300);
    base.addColorStop(0, 'rgba(99,102,241,0.9)');
    base.addColorStop(1, 'rgba(139,92,246,0.5)');
    charts.category = new Chart(ctx, {
      type: 'bar',
      data: { labels: [], datasets: [{ label: 'Category Revenue', data: [], backgroundColor: base, borderRadius: 8, maxBarThickness: 42 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => Utils.currency(c.parsed.y) } } },
        scales: {
          y: { beginAtZero: true, grid: { color: themePalette().grid }, ticks: { callback: moneyTick } },
          x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
      }
    });
  }

  /* ================= 3. Order Status (doughnut) ================= */
  function createStatusChart(canvas) {
    charts.status = new Chart(canvas.getContext('2d'), {
      type: 'doughnut',
      data: { labels: ['Completed', 'Pending', 'Cancelled'], datasets: [{ data: [0, 0, 0], backgroundColor: ['#22c55e', '#f59e0b', '#ef4444'], borderColor: themePalette().border, borderWidth: 2, hoverOffset: 8 }] },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '68%',
        plugins: {
          legend: { position: 'bottom', labels: { padding: 16, font: { size: 12 } } },
          tooltip: { callbacks: {
            label: c => {
              const total = c.dataset.data.reduce((a, b) => a + b, 0) || 1;
              return ' ' + c.label + ': ' + c.parsed + ' (' + Math.round((c.parsed / total) * 100) + '%)';
            }
          } }
        }
      }
    });
  }

  /* ================= 4. Top Products (horizontal bar) ================= */
  function createProductChart(canvas) {
    const ctx = canvas.getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 300, 0);
    grad.addColorStop(0, '#22d3ee');
    grad.addColorStop(1, '#6366f1');
    charts.product = new Chart(ctx, {
      type: 'bar',
      data: { labels: [], datasets: [{ label: 'Revenue', data: [], backgroundColor: grad, borderRadius: 7, maxBarThickness: 20 }] },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => Utils.currency(c.parsed.x) } } },
        scales: {
          x: { beginAtZero: true, grid: { color: themePalette().grid }, ticks: { callback: moneyTick } },
          y: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
      }
    });
  }

  /* ================= 5. Customer Growth (area) ================= */
  function createCustomerChart(canvas) {
    const ctx = canvas.getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 300);
    grad.addColorStop(0, 'rgba(34,211,238,0.4)');
    grad.addColorStop(1, 'rgba(34,211,238,0)');
    charts.customer = new Chart(ctx, {
      type: 'line',
      data: { labels: [], datasets: [{ label: 'New Customers', data: [], borderColor: '#22d3ee', backgroundColor: grad, fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 0, pointHoverRadius: 5 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => 'New customers: ' + c.parsed.y } } },
        scales: {
          y: { beginAtZero: true, grid: { color: themePalette().grid }, ticks: { precision: 0 } },
          x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
      }
    });
  }

  /* ============ Initialization ============ */
  function init() {
    createRevenueChart(document.getElementById('revenueChart'));
    createCategoryChart(document.getElementById('categoryChart'));
    createStatusChart(document.getElementById('statusChart'));
    createProductChart(document.getElementById('productChart'));
    createCustomerChart(document.getElementById('customerChart'));
  }

  /* ============ Update functions ============ */

  /** Update revenue trend chart with daily & monthly series. */
  function updateRevenueChart(dailyLabels, dailyData, monthlyLabels, monthlyData) {
    if (!charts.revenue) return;
    const dailyIdx = charts.revenue.data.datasets[0];
    const monthlyIdx = charts.revenue.data.datasets[1];
    // Main series = monthly by default (smoother), daily as dashed overlay
    dailyIdx.label = 'Daily Revenue';
    dailyIdx.data = dailyData;
    monthlyIdx.label = 'Orders';
    monthlyIdx.data = monthlyData;
    charts.revenue.data.labels = dailyLabels;

    // Choose visible/main series labels depending on density handled by caller:
    // We always show daily labels; monthly is background.
    dailyIdx.yAxisID = 'y';
    monthlyIdx.yAxisID = 'yOrders';
    charts.revenue.update('none');
  }

  function updateCategoryChart(labels, data) {
    if (!charts.category) return;
    charts.category.data.labels = labels;
    charts.category.data.datasets[0].data = data;
    charts.category.update('none');
  }

  function updateStatusChart(labels, data) {
    if (!charts.status) return;
    charts.status.data.labels = labels;
    charts.status.data.datasets[0].data = data;
    charts.status.update('none');
  }

  function updateProductChart(labels, data) {
    if (!charts.product) return;
    charts.product.data.labels = labels;
    charts.product.data.datasets[0].data = data;
    charts.product.update('none');
  }

  function updateCustomerChart(labels, data) {
    if (!charts.customer) return;
    charts.customer.data.labels = labels;
    charts.customer.data.datasets[0].data = data;
    charts.customer.update('none');
  }

  /** Recreate all charts (used after theme change / resize). */
  function destroy() {
    Object.keys(charts).forEach(k => {
      if (charts[k]) { charts[k].destroy(); charts[k] = null; }
    });
  }
  function rebuild() { destroy(); init(); }

  global.ChartsApp = {
    init,
    updateRevenueChart,
    updateCategoryChart,
    updateStatusChart,
    updateProductChart,
    updateCustomerChart,
    destroy,
    rebuild,
    themePalette,
    getCharts: () => charts
  };
})(window);
