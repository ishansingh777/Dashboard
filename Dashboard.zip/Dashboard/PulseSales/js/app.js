/* ============================================================
   PulseSales — app.js
   Login page logic backed by Supabase Auth.
   ============================================================ */
(function () {
  'use strict';

  const form = document.getElementById('loginForm');
  const emailInput = document.getElementById('loginEmail');
  const passwordInput = document.getElementById('loginPassword');
  const errorEl = document.getElementById('loginError');
  const loginBtn = document.getElementById('loginBtn');
  const btnLabel = loginBtn.querySelector('.btn-label');
  const toggle = document.getElementById('passwordToggle');
  const rememberMe = document.getElementById('rememberMe');
  const nameInput = document.getElementById('loginName');
  const confirmPassword = document.getElementById('confirmPassword');
  const nameField = document.getElementById('nameField');
  const confirmPasswordField = document.getElementById('confirmPasswordField');
  const signupLink = document.getElementById('signupLink');
  const authSwitch = document.getElementById('authSwitch');
  const forgotPassword = document.getElementById('forgotPassword');
  let signupMode = false;

  function setMode(signup) {
    signupMode = signup;
    nameField.style.display = signup ? '' : 'none';
    confirmPasswordField.style.display = signup ? '' : 'none';
    nameInput.required = signup;
    confirmPassword.required = signup;
    document.querySelector('.auth-title').textContent = signup ? 'Create your account' : 'Welcome back';
    document.querySelector('.auth-subtitle').textContent = signup ? 'Start using your PulseSales workspace' : 'Sign in to your PulseSales workspace';
    btnLabel.textContent = signup ? 'Create account' : 'Sign In';
    forgotPassword.parentElement.style.display = signup ? 'none' : '';
    authSwitch.innerHTML = signup ? 'Already have an account? <a href="#" class="link" id="signupLink">Sign in</a>' : 'New to PulseSales? <a href="#" class="link" id="signupLink">Create an account</a>';
    authSwitch.querySelector('#signupLink').addEventListener('click', e => { e.preventDefault(); setMode(!signupMode); });
    errorEl.textContent = '';
  }

  // Password visibility toggle
  toggle.addEventListener('click', () => {
    const isPwd = passwordInput.type === 'password';
    passwordInput.type = isPwd ? 'text' : 'password';
    toggle.style.opacity = isPwd ? '1' : '.6';
  });

  signupLink.addEventListener('click', e => { e.preventDefault(); setMode(true); });
  forgotPassword.addEventListener('click', async e => {
    e.preventDefault();
    const email = emailInput.value.trim().toLowerCase();
    if (!email) { errorEl.textContent = 'Enter your email first to reset your password.'; return; }
    const { error } = await PulseSalesAuth.resetPassword(email);
    errorEl.style.color = error ? 'var(--red)' : 'var(--green)';
    errorEl.textContent = error ? (error.message || 'Password reset failed.') : 'Password reset email sent.';
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.textContent = '';
    const email = emailInput.value.trim().toLowerCase();
    const password = passwordInput.value;

    if (!email || !password || (signupMode && !nameInput.value.trim())) {
      errorEl.textContent = signupMode ? 'Enter your name, email, and password.' : 'Please enter your email and password.';
      return;
    }
    if (signupMode && password !== confirmPassword.value) {
      errorEl.textContent = 'Passwords do not match.';
      return;
    }

    // Loading state
    loginBtn.disabled = true;
    btnLabel.innerHTML = '<span class="spinner"></span> Signing in…';

    try {
      if (!window.PulseSalesSupabase.configured) throw new Error('Supabase is not configured.');
      const result = signupMode ? await PulseSalesAuth.signUp(email, password, { name: nameInput.value.trim() }) : await PulseSalesAuth.signIn(email, password);
      const { data, error } = result;
      if (error) {
        errorEl.style.color = 'var(--red)';
        errorEl.textContent = error.message || (signupMode ? 'Could not create account.' : 'Invalid login credentials.');
        return;
      }
      if (signupMode && !data.session) {
        errorEl.style.color = 'var(--green)';
        setMode(false);
        errorEl.style.color = 'var(--green)';
        errorEl.textContent = 'Account created. Check your email to confirm, then sign in.';
        return;
      }
      if (rememberMe.checked) localStorage.setItem('pulsesales_remember', email);
      sessionStorage.setItem('pulsesales_user', JSON.stringify(data.user));

      window.location.href = './dashboard.html';
    } catch (err) {
      errorEl.style.color = 'var(--red)';
      errorEl.textContent = err.message || 'Could not connect to Supabase.';
    } finally {
      loginBtn.disabled = false;
      btnLabel.textContent = signupMode ? 'Create account' : 'Sign In';
    }
  });

  // Prefill from remember-me / saved session
  const saved = localStorage.getItem('pulsesales_remember');
  if (saved) emailInput.value = saved;
})();
