/* ============================================================
   PulseSales — filters.js
   Date-range filtering, search & status filters.
   ============================================================ */
(function (global) {
  'use strict';

  const Filters = {
    state: {
      range: '7days',
      orderStatus: 'all',
      productCategory: 'all',
      orderQuery: '',
      customerQuery: '',
      productQuery: '',
      globalQuery: ''
    },

    /** Currently applying date range (set by dashboard.js). */
    activeRange: null,

    /** Set the active date range object { start, end, label }. */
    setRange(rangeObj) {
      this.activeRange = rangeObj;
    },

    /** Does a sale fall inside the active range? */
    inRange(sale) {
      if (!this.activeRange) return true;
      return sale.date >= this.activeRange.start && sale.date <= this.activeRange.end;
    },

    /** Filter orders for the orders table (range + query + status). */
    filterOrders(orders, customersById, productsById) {
      let out = orders.filter(o => this.inRange(o));
      const q = this.state.orderQuery.toLowerCase();
      if (q) {
        out = out.filter(o => {
          const cust = customersById[o.customerId];
          const prod = productsById[o.productId];
          return (
            String(o.id).toLowerCase().includes(q) ||
            String(o.status).toLowerCase().includes(q) ||
            String(o.payment).toLowerCase().includes(q) ||
            String(o.region).toLowerCase().includes(q) ||
            (cust && cust.name.toLowerCase().includes(q)) ||
            (prod && prod.name.toLowerCase().includes(q))
          );
        });
      }

      if (this.state.orderStatus !== 'all') {
        out = out.filter(o => o.status === this.state.orderStatus);
      }
      return out;
    },

    /** Filter customers by search, enriched with computed metrics. */
    filterCustomers(list, query) {
      const q = (query ?? this.state.customerQuery).toLowerCase();
      if (!q) return list;
      return list.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        String(c.id).includes(q)
      );
    },

    /** Filter products by search + category. */
    filterProducts(list) {
      let out = list.slice();
      const q = this.state.productQuery.toLowerCase();
      if (q) {
        out = out.filter(p =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          String(p.id).includes(q)
        );
      }
      if (this.state.productCategory !== 'all') {
        out = out.filter(p => p.category === this.state.productCategory);
      }
      return out;
    },

    /** Reset all search queries. */
    reset() {
      this.state.orderQuery = '';
      this.state.customerQuery = '';
      this.state.productQuery = '';
      this.state.globalQuery = '';
      this.state.orderStatus = 'all';
      this.state.productCategory = 'all';
    }
  };

  global.Filters = Filters;
})(window);
