// Supabase project configuration. Keep the publishable key in this file only.
const SUPABASE_URL = 'https://xszcjscywohhsesyuecb.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable__WxXTCLChV86h6upR7UBgg_PzxwgHFD';

