/* ============================================================
   PulseSales — dashboard.js
   Loads live data, computes metrics, renders UI, drives filters,
   tables, KPI cards, exports and charts.
   ============================================================ */
(function () {
  'use strict';

  const App = {
    data: { sales: [], customers: [], products: [], users: [] },
    enums: { categories: [] },
    chartsDone: false,
    realtimeChannel: null,
    liveRefreshTimer: null,
    eventsBound: false,

    /* ---------- State for tables ---------- */
    ordersStore: [],
    customersStore: [],
    productsStore: [],
    ordersPage: 1,
    customersPage: 1,
    productsPage: 1,
    pageSize: 8,
    sort: { field: 'date', dir: -1 },

    /* ========== LIFECYCLE ========== */
    async init() {
      if (!this.eventsBound) { this.bindStatic(); this.eventsBound = true; }
      this.restoreTheme();
      this.renderUser();
      this.showSkeleton(true);
      try {
        if (!await PulseSalesAuth.requireSession()) return;
        await this.loadData();
        this.afterLoad();
        this.applyRangeRefresh();
        if (!this.realtimeChannel) {
          this.realtimeChannel = PulseSalesApi.subscribe(() => this.scheduleLiveRefresh());
        }
        this.showSkeleton(false);
      } catch (err) {
        this.showSkeleton(false);
        this.showError(navigator.onLine ? (err.message || 'Connection to Supabase failed.') : 'You are offline. Check your connection and retry.');
      }
    },

    async loadData() {
      const next = await PulseSalesApi.loadDashboardData();
      this.data = next;
      this.enums.categories = [...new Set(next.products.map(p => p.category))].sort();
    },

    async refreshLiveData() {
      try {
        await this.loadData();
        this.afterLoad();
        this.applyRangeRefresh();
      } catch (err) {
        this.showError(navigator.onLine ? 'Live update failed. Retry to reconnect.' : 'You are offline. Check your connection and retry.');
      }
    },

    scheduleLiveRefresh() {
      clearTimeout(this.liveRefreshTimer);
      this.liveRefreshTimer = setTimeout(() => this.refreshLiveData(), 250);
    },
    afterLoad() {
      // Build stores
      this.ordersStore = this.data.sales.map(s => ({ ...s }));
      this.customerEnriched = this.buildCustomers();
      this.productEnriched = this.buildProducts();

      this.populateCategoryFilter();

      // nav badges
      document.getElementById('ordersNavBadge').textContent = this.data.sales.length;
      document.getElementById('customersNavBadge').textContent = this.data.customers.length;

      // Reveal chart canvas boxes BEFORE init so charts get real dimensions
      document.querySelectorAll('.chart-box').forEach(box => { box.style.display = 'block'; });
      document.querySelectorAll('.skeleton').forEach(s => { s.style.display = 'none'; });

      // Init charts
      if (!this.chartsDone) {
        ChartsApp.init();
        this.chartsDone = true;
      }
    },

    /* ========== REBUILD ALL FOR ACTIVE RANGE ========== */
    applyRangeRefresh() {
      // Temporarily bypass filtering to load all data
      document.getElementById('dateLabel').textContent = 'All Time';
      this.updatePageSubtitle({ label: 'All Time' });
      this.renderKPIs();
      
      try {
        this.renderCharts();
      } catch (e) {
        console.error("Error rendering charts:", e);
      }
      
      try {
        this.renderOrdersTable();
        this.renderCustomersTable();
        this.renderProductsTable();
      } catch (e) {
        console.error("Error rendering tables:", e);
      }
    },

    renderKPIs() {
      const orders = this.data.sales || [];
      const users = this.data.customers || [];

      const totalRevenue = orders.reduce((sum, item) => sum + Number(item.amount || 0), 0);
      const totalOrders = orders.length;
      const totalDiscount = orders.reduce((sum, item) => sum + Number(item.discount || 0), 0);
      const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
      const totalCustomers = users.length;

      const cards = [
        { label: 'Total Revenue', value: totalRevenue, fmt: v => Utils.currency(v), icon: '$', cls: 'ic-a', sub: 'All data' },
        { label: 'Total Orders', value: totalOrders, fmt: v => Utils.number(v), icon: '🧾', cls: 'ic-b', sub: 'All data' },
        { label: 'Total Discount', value: totalDiscount, fmt: v => Utils.currency(v), icon: '📉', cls: 'ic-c', sub: 'All data' },
        { label: 'Avg Order Value', value: avgOrderValue, fmt: v => Utils.currency(v), icon: '🎯', cls: 'ic-d', sub: 'All data' },
        { label: 'Total Customers', value: totalCustomers, fmt: v => Utils.number(v), icon: '👥', cls: 'ic-e', sub: 'All data' }
      ];

      this.renderKpiGrid(cards);
    },

    renderKpiGrid(cards) {
      const grid = document.getElementById('kpiGrid');
      grid.innerHTML = cards.map((c, i) => `
        <div class="kpi-card" style="animation-delay:${i * 0.04}s">
          <div class="label">${Utils.escapeHtml(c.label)}</div>
          <div class="value ${c.label === 'Best Seller' || c.label === 'Lowest Seller' ? 'small' : ''}" ${typeof c.value === 'number' ? `data-target="${c.value}"` : ''} data-fmt="${btoa(unescape(encodeURIComponent(c.fmt.toString())))}">${typeof c.value === 'number' ? '0' : Utils.escapeHtml(c.value)}</div>
          <div class="sub">${Utils.escapeHtml(c.sub)}</div>
        </div>
      `).join('');

      // Animate counters
      grid.querySelectorAll('.value[data-target]').forEach(el => {
        const target = Number(el.dataset.target);
        let fmt = v => Utils.number(v);
        try { fmt = eval('(' + decodeURIComponent(escape(atob(el.dataset.fmt))) + ')'); } catch (e) {}
        Utils.animateNumber(el, target, fmt, 900);
      });
    },

    /* ========== CHARTS ========== */
    renderCharts() {
      const range = Filters.activeRange;
      const sales = (this.data.sales || []).filter(s => this.inRangeRange(s, range));

      // --- Revenue trend (daily) ---
      const dailyMap = new Map();
      const dailyOrders = new Map();
      const monthlyMap = new Map();
      sales.forEach(s => {
        const d = s.date;
        dailyMap.set(d, (dailyMap.get(d) || 0) + s.amount);
        dailyOrders.set(d, (dailyOrders.get(d) || 0) + 1);
        const m = d.slice(0, 7);
        monthlyMap.set(m, (monthlyMap.get(m) || 0) + s.amount);
      });

      // Order the days
      const dailyKeys = [...dailyMap.keys()].sort();
      const dailyRev = dailyKeys.map(k => dailyMap.get(k));
      const dailyOrderData = dailyKeys.map(k => dailyOrders.get(k));

      // Resample to a reasonable number of points
      const sample = this.resampleSeries(dailyKeys, dailyRev, range);
      const orderSample = this.resampleSeries(dailyKeys, dailyOrderData, range);
      const dailyLabels = sample.labels;
      const dailyData = sample.data;

      // Monthly average overlay (aligned by first-of-month label)
      const monthLabels = [...monthlyMap.keys()].sort();
      const monthData = monthLabels.map(k => monthlyMap.get(k));
      const monthlySeriesLabels = monthLabels.map(k => this.monthShort(k));

      // Provide synthetic label alignment: monthly forced as its own category labels.
      // Since dual-axis uses same x labels, we map monthly by 1-to-1 on days of first occurrence.
      const dailyOrderAligned = dailyLabels.map((_, i) => orderSample.data[i] ?? null);

      ChartsApp.updateRevenueChart(
        dailyLabels,
        dailyData,
        dailyLabels,
        dailyOrderAligned
      );
      this.toggleSkeleton('rev', dailyLabels.length > 0);

      // --- Category revenue ---
      const catMap = new Map();
      sales.forEach(s => {
        const p = this.productById(s.productId);
        const cat = p ? p.category : 'Unknown';
        catMap.set(cat, (catMap.get(cat) || 0) + s.amount);
      });
      const catLabels = [...catMap.keys()];
      const catData = catLabels.map(k => Math.round(catMap.get(k)));
      ChartsApp.updateCategoryChart(catLabels, catData);
      this.toggleSkeleton('cat', catLabels.length > 0);

      // --- Orders over time (status chart slot retained to preserve the UI) ---
      ChartsApp.updateStatusChart(dailyKeys.map(k => Utils.shortDate(k)), dailyOrderData);
      this.toggleSkeleton('status', sales.length > 0);

      // --- Top 10 products ---
      const prodMap = this.revenueByProduct(sales);
      const top = [...prodMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10);
      const prodDefs = new Map(this.data.products.map(p => [p.id, p.name]));
      const prodLabels = top.map(([id]) => prodDefs.get(id) || '#' + id);
      const prodData = top.map(([, v]) => Math.round(v));
      ChartsApp.updateProductChart(prodLabels, prodData);
      this.toggleSkeleton('prod', top.length > 0);

      // --- Customer growth (new customers per month) ---
      const joinMap = new Map();
      this.data.customers.forEach(c => {
        const m = (c.joinDate || '2000-01').slice(0, 7);
        joinMap.set(m, (joinMap.get(m) || 0) + 1);
      });
      const joinKeys = [...joinMap.keys()].sort();
      const joinLabels = joinKeys.map(k => this.monthShort(k));
      const joinData = joinKeys.map(k => joinMap.get(k));
      ChartsApp.updateCustomerChart(joinLabels, joinData);
      this.toggleSkeleton('cust', joinData.length > 0);
    },

    resampleSeries(labels, data, range) {
      if (labels.length <= 14) return { labels: labels.map(l => Utils.shortDate(l)), data };
      // Downsample by picking evenly spaced points
      const max = 20;
      const step = Math.ceil(labels.length / max);
      const outL = [], outD = [];
      for (let i = 0; i < labels.length; i += step) {
        outL.push(Utils.shortDate(labels[i]));
        outD.push(data[i]);
      }
      if (outL[outL.length - 1] !== Utils.shortDate(labels[labels.length - 1])) {
        outL.push(Utils.shortDate(labels[labels.length - 1]));
        outD.push(data[data.length - 1]);
      }
      return { labels: outL, data: outD };
    },

    monthShort(key) {
      const d = new Date(key.slice(0, 4), Number(key.slice(5, 7)) - 1, 1);
      return d.toLocaleDateString('en-IN', { month: 'short' });
    },

    /* ========== ORDERS TABLE ========== */
    buildOrdersRows() {
      const custMap = new Map(this.data.customers.map(c => [c.id, c]));
      const prodMap = new Map(this.data.products.map(p => [p.id, p]));
      const range = Filters.activeRange;
      let rows = this.data.sales.filter(s => this.inRangeRange(s, range)).map(s => ({
        ...s,
        customerName: custMap.get(s.customerId)?.name || 'Unknown',
        productName: prodMap.get(s.productId)?.name || 'Unknown'
      }));
      rows = Filters.filterOrders(rows, custMap, prodMap);
      return rows;
    },

    renderOrdersTable() {
      const rows = this.buildOrdersRows();
      const { sorted, pageRows, page, pages } = this.paginate(rows, this.ordersPage, this.sort);
      this.ordersPage = page;
      this.renderTable(
        'ordersTable', 'ordersHead', 'ordersBody', 'ordersEmpty', pageRows, 'ordersPagination',
        rows.length, page, pages,
        [
          { key: 'id', label: 'Order ID', render: o => `<span class="id-badge">#${o.id}</span>`, sortable: true },
          { key: 'customerName', label: 'Customer', render: o => this.cellPerson(o.customerName), sortable: true },
          { key: 'productName', label: 'Product', render: o => `<span>${Utils.escapeHtml(o.productName)}</span>`, sortable: false },
          { key: 'amount', label: 'Amount', render: o => `<span class="amount">${Utils.currency(o.amount)}</span>`, sortable: true, num: true },
          { key: 'status', label: 'Status', render: o => this.statusBadge(o.status), sortable: true },
          { key: 'payment', label: 'Payment', render: o => this.paymentBadge(o.payment), sortable: true },
          { key: 'region', label: 'Region', render: o => `<span class="muted">${Utils.escapeHtml(o.region)}</span>`, sortable: true },
          { key: 'date', label: 'Date', render: o => `<span>${Utils.formatDate(o.date)}</span>`, sortable: true }
        ],
        this.handleOrderHeaderClick.bind(this)
      );
    },

    /* ========== CUSTOMERS TABLE ========== */
    buildCustomers() {
      const range = Filters.activeRange;
      const map = new Map();
      // only count sales in range
      this.data.sales.forEach(s => {
        if (s.status === 'Cancelled') return;
        if (!this.inRangeRange(s, range)) return;
        const rec = map.get(s.customerId) || { orders: 0, spend: 0, last: '1900-01-01' };
        rec.orders++;
        rec.spend += s.amount;
        if (s.date > rec.last) rec.last = s.date;
        map.set(s.customerId, rec);
      });
      return this.data.customers.map(c => ({
        ...c,
        orders: map.get(c.id)?.orders || 0,
        spend: map.get(c.id)?.spend || 0,
        last: map.get(c.id)?.last || null
      }));
    },

    renderCustomersTable() {
      let rows = this.customerEnriched;
      rows = Filters.filterCustomers(rows);
      // sort by spend desc
      const sorted = [...rows].sort((a, b) => b.spend - a.spend);
      const { pageRows, page, pages } = this.paginate(sorted, this.customersPage, { field: 'spend', dir: -1 });
      this.customersPage = page;
      this.renderTable(
        'customersTable', 'customersHead', 'customersBody', 'customersEmpty', pageRows, 'customersPagination',
        sorted.length, page, pages,
        [
          { key: 'name', label: 'Customer', render: c => this.cellPerson(c.name, c.email), sortable: false },
          { key: 'email', label: 'Email', render: c => `<span class="muted">${Utils.escapeHtml(c.email)}</span>`, sortable: false },
          { key: 'orders', label: 'Orders', render: c => `<span class="num">${c.orders}</span>`, sortable: false },
          { key: 'spend', label: 'Total Spending', render: c => `<span class="amount">${Utils.currency(c.spend)}</span>`, sortable: false },
          { key: 'last', label: 'Last Purchase', render: c => c.last ? `<span>${Utils.formatDate(c.last)}</span>` : `<span class="muted">Never</span>`, sortable: false }
        ],
        null
      );
    },

    /* ========== PRODUCTS TABLE ========== */
    buildProducts() {
      const range = Filters.activeRange;
      const map = new Map();
      this.data.sales.forEach(s => {
        if (!this.inRangeRange(s, range)) return;
        const rec = map.get(s.productId) || { units: 0, revenue: 0, discount: 0 };
        rec.units += s.quantity;
        rec.revenue += s.amount;
        rec.discount += s.discount;
        map.set(s.productId, rec);
      });
      return this.data.products.map(p => {
        const m = map.get(p.id) || { units: 0, revenue: 0, discount: 0 };
        return { ...p, units: m.units, revenue: m.revenue, profit: m.discount };
      });
    },

    populateCategoryFilter() {
      const sel = document.getElementById('productCategoryFilter');
      sel.innerHTML = '<option value="all">All</option>' +
        this.enums.categories.map(c => `<option value="${Utils.escapeHtml(c)}">${Utils.escapeHtml(c)}</option>`).join('');
    },

    renderProductsTable() {
      let rows = this.productEnriched;
      rows = Filters.filterProducts(rows);
      const sorted = [...rows].sort((a, b) => b.revenue - a.revenue);
      const { pageRows, page, pages } = this.paginate(sorted, this.productsPage, { field: 'revenue', dir: -1 });
      this.productsPage = page;
      this.renderTable(
        'productsTable', 'productsHead', 'productsBody', 'productsEmpty', pageRows, 'productsPagination',
        sorted.length, page, pages,
        [
          { key: 'name', label: 'Product', render: p => `<span>${Utils.escapeHtml(p.name)}</span>`, sortable: false },
          { key: 'category', label: 'Category', render: p => `<span class="muted">${Utils.escapeHtml(p.category)}</span>`, sortable: false },
          { key: 'units', label: 'Units Sold', render: p => `<span class="num">${p.units}</span>`, sortable: false },
          { key: 'revenue', label: 'Revenue', render: p => `<span class="amount">${Utils.currency(p.revenue)}</span>`, sortable: false },
          { key: 'profit', label: 'Discount', render: p => `<span class="amount">${Utils.currency(p.profit)}</span>`, sortable: false },
          { key: 'stock', label: 'Stock', render: p => this.stockBadge(p.stock), sortable: false }
        ],
        null
      );
    },

    /* ========== SHARED TABLE RENDERER ========== */
    renderTable(tableId, headId, bodyId, emptyId, rows, pagId, total, page, pages, cols, onHeadClick) {
      const headEl = document.getElementById(headId);
      headEl.innerHTML = '<tr>' + cols.map((c, i) =>
        `<th data-idx="${i}" ${c.sortable ? 'class="sortable"' : ''}>${Utils.escapeHtml(c.label)}${c.sortable ? '<span class="sort-arrow"></span>' : ''}</th>`
      ).join('') + '</tr>';

      const bodyEl = document.getElementById(bodyId);
      if (!rows.length) {
        document.getElementById(emptyId).style.display = 'flex';
        bodyEl.innerHTML = '';
      } else {
        document.getElementById(emptyId).style.display = 'none';
        bodyEl.innerHTML = rows.map(r => '<tr>' + cols.map(c => `<td>${c.render(r)}</td>`).join('') + '</tr>').join('');
      }

      this.renderPagination(pagId, page, pages, total);
      if (onHeadClick) {
        headEl.querySelectorAll('th.sortable').forEach(th => {
          th.onclick = () => onHeadClick(Number(th.dataset.idx));
        });
      }
    },

    renderPagination(pagId, page, pages, total) {
      const el = document.getElementById(pagId);
      const from = total ? (page - 1) * this.pageSize + 1 : 0;
      const to = Math.min(page * this.pageSize, total);
      let btns = '';
      const pagesArr = this.pageWindow(page, pages);
      for (const p of pagesArr) {
        if (p === '…') btns += `<button disabled>…</button>`;
        else btns += `<button class="${p === page ? 'active' : ''}" data-page="${p}">${p}</button>`;
      }
      el.innerHTML = `
        <span class="info">Showing <b>${from}</b>–<b>${to}</b> of <b>${total}</b></span>
        <div class="pages">
          <button data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>‹</button>
          ${btns}
          <button data-page="${page + 1}" ${page >= pages ? 'disabled' : ''}>›</button>
        </div>
      `;
      el.querySelectorAll('button[data-page]').forEach(b => {
        b.onclick = () => {
          const target = Number(b.dataset.page);
          if (target < 1 || target > pages) return;
          const table = pagId; // use id to route
          if (table === 'ordersPagination') this.ordersPage = target;
          else if (table === 'customersPagination') this.customersPage = target;
          else if (table === 'productsPagination') this.productsPage = target;
          this.reRenderTables();
        };
      });
    },

    pageWindow(page, pages, size) {
      size = size || 5;
      if (pages <= size) return Array.from({ length: pages }, (_, i) => i + 1);
      const half = Math.floor(size / 2);
      let start = Math.max(1, page - half);
      let end = start + size - 1;
      if (end > pages) { end = pages; start = pages - size + 1; }
      const arr = [];
      if (start > 1) { arr.push(1); if (start > 2) arr.push('…'); }
      for (let i = start; i <= end; i++) arr.push(i);
      if (end < pages) { if (end < pages - 1) arr.push('…'); arr.push(pages); }
      return arr;
    },

    reRenderTables() {
      this.renderOrdersTable();
      this.renderCustomersTable();
      this.renderProductsTable();
    },

    handleOrderHeaderClick(idx) {
      const fields = ['id', 'customerName', 'productName', 'amount', 'status', 'payment', 'region', 'date'];
      const field = fields[idx];
      if (!field) return;
      if (this.sort.field === field) this.sort.dir *= -1;
      else { this.sort.field = field; this.sort.dir = -1; }
      this.ordersPage = 1;
      this.renderOrdersTable();
    },

    /* ========== HELPERS ========== */
    paginate(rows, page, sort) {
      const sorted = this.sortRows(rows, sort);
      const pages = Math.max(1, Math.ceil(sorted.length / this.pageSize));
      const clamped = Math.min(Math.max(1, page), pages);
      const start = (clamped - 1) * this.pageSize;
      return { sorted, pageRows: sorted.slice(start, start + this.pageSize), page: clamped, pages };
    },

    sortRows(rows, sort) {
      if (!sort || !sort.field) return rows;
      return [...rows].sort((a, b) => {
        const av = a[sort.field];
        const bv = b[sort.field];
        if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * sort.dir;
        return String(av).localeCompare(String(bv)) * sort.dir;
      });
    },

    revenueByProduct(sales) {
      const map = new Map();
      sales.forEach(s => {
        map.set(s.productId, (map.get(s.productId) || 0) + s.amount);
      });
      return map;
    },

    orderCountByProduct(sales) {
      const map = new Map();
      sales.forEach(s => map.set(s.productId, (map.get(s.productId) || 0) + 1));
      return map;
    },

    productById(id) {
      return this.data.products.find(p => p.id === id) || null;
    },

    inRangeRange(s, range) {
      return true;
    },

    sum(arr, field) { return arr.reduce((a, b) => a + (Number(b[field]) || 0), 0); },
    pctSafe(part, total) { return total ? Math.round((part / total) * 1000) / 10 : 0; },
    shorten(str) { return String(str).length > 16 ? String(str).slice(0, 15) + '…' : str; },

    /* ========== BADGES & CELLS ========== */
    statusBadge(s) {
      const cls = String(s).toLowerCase();
      return `<span class="badge ${cls}">${Utils.escapeHtml(s)}</span>`;
    },
    paymentBadge(p) {
      const cls = String(p).toLowerCase();
      return `<span class="badge ${cls}">${Utils.escapeHtml(p)}</span>`;
    },
    stockBadge(stock) {
      if (stock == null) return '<span class="badge">—</span>';
      if (stock <= 10) return `<span class="badge critical">Low</span>`;
      if (stock <= 24) return `<span class="badge low">${stock} left</span>`;
      return `<span class="badge ok">${stock}</span>`;
    },
    cellPerson(name, email) {
      const color = Utils.colorFromString(name || '?');
      const init = Utils.initials(name || '?');
      return `<div class="cell-main"><span class="ava" style="background:${color}">${Utils.escapeHtml(init)}</span><div>${Utils.escapeHtml(name)}${email ? `<div class="muted" style="font-size:11.5px">${Utils.escapeHtml(email)}</div>` : ''}</div></div>`;
    },

    /* ========== SKELETON / ERROR / THEME ========== */
    showSkeleton(show) {
      const t = { rev: 'revSkeleton', cat: 'catSkeleton', status: 'statusSkeleton', prod: 'prodSkeleton', cust: 'custSkeleton' };
      // no-op container; individual toggles handled elsewhere
      document.querySelectorAll('.skeleton').forEach(s => s.style.display = show ? '' : 'block');
    },
    toggleSkeleton(kind, hasData) {
      const map = { rev: ['revSkeleton', 'revenueChartBox'], cat: ['catSkeleton', 'categoryChartBox'], status: ['statusSkeleton', 'statusChartBox'], prod: ['prodSkeleton', 'prodChartBox'], cust: ['custSkeleton', 'custChartBox'] };
      const pair = map[kind];
      if (!pair) return;
      const skel = document.getElementById(pair[0]);
      const box = document.getElementById(pair[1]);
      if (skel) skel.style.display = hasData ? 'none' : 'block';
      if (box) box.style.display = hasData ? 'block' : 'none';
    },
    showError(msg) {
      const banner = document.getElementById('errorBanner');
      if (!banner) return;
      banner.style.display = 'flex';
      banner.querySelector('span').textContent = msg;
    },

    restoreTheme() {
      const saved = localStorage.getItem('pulsesales_theme');
      const dark = saved ? saved === 'dark' : true;
      document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
      this.themeIcon();
    },
    themeIcon() {
      const btn = document.getElementById('themeToggle');
      if (!btn) return;
      const dark = document.documentElement.getAttribute('data-theme') !== 'light';
      btn.textContent = dark ? '🌙' : '☀️';
    },
    toggleTheme() {
      const dark = document.documentElement.getAttribute('data-theme') !== 'light';
      document.documentElement.setAttribute('data-theme', dark ? 'light' : 'dark');
      localStorage.setItem('pulsesales_theme', dark ? 'light' : 'dark');
      this.themeIcon();
      // Rebuild charts to pick up color changes
      ChartsApp.rebuild();
      // Re-render current data into new charts
      this.renderCharts();
    },

    renderUser() {
      const raw = sessionStorage.getItem('pulsesales_user');
      let name = 'Admin', role = 'Administrator';
      if (raw) {
        try { const u = JSON.parse(raw); name = u.name || name; role = u.role || role; } catch (e) {}
      }
      const users = document.querySelectorAll('#userName,#topUserName');
      users.forEach(el => el.textContent = name.split(' ')[0]);
      document.getElementById('userRole').textContent = role;
      document.getElementById('topUserRole').textContent = role;
    },

    updatePageSubtitle(range) {
      document.getElementById('pageSubtitle').textContent = range.label;
    },

    /* ========== EXPORTS ========== */
    exportCSV() {
      const type = 'sales';
      let header, rows;
      if (type === 'sales') {
        header = ['Order ID', 'Customer', 'Product', 'Amount', 'Status', 'Payment', 'Region', 'Date'];
        const custMap = new Map(this.data.customers.map(c => [c.id, c]));
        const prodMap = new Map(this.data.products.map(p => [p.id, p]));
        rows = this.buildOrdersRows().map(s => [
          s.id, custMap.get(s.customerId)?.name || '', prodMap.get(s.productId)?.name || '',
          Utils.currency(s.amount), s.status, s.payment, s.region, s.date
        ]);
      }
      this.downloadCSV(header, rows, 'pulsesales-orders.csv');
      Utils.toast('Sales CSV exported', 'success');
    },

    exportCSVTable(table) {
      let header, rows;
      if (table === 'customers') {
        header = ['ID', 'Name', 'Email', 'City', 'Join Date', 'Orders', 'Total Spending'];
        rows = this.customerEnriched.map(c => [c.id, c.name, c.email, c.city, c.joinDate, c.orders, Utils.currency(c.spend)]);
      } else if (table === 'products') {
        header = ['ID', 'Product', 'Destination Coverage', 'Price', 'Units Sold', 'Revenue', 'Discount', 'Stock'];
        rows = this.productEnriched.map(p => [p.id, p.name, p.category, Utils.currency(p.price), p.units, Utils.currency(p.revenue), Utils.currency(p.profit), p.stock]);
      } else return;
      this.downloadCSV(header, rows, `pulsesales-${table}.csv`);
      Utils.toast(table[0].toUpperCase() + table.slice(1) + ' CSV exported', 'success');
    },

    downloadCSV(header, rows, filename) {
      const escape = v => {
        v = String(v == null ? '' : v);
        return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
      };
      const csv = [header.map(escape).join(',')]
        .concat(rows.map(r => r.map(escape).join(',')))
        .join('\n');
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    },

    /* ========== PDF REPORT ========== */
    pdfReport() {
      const range = Filters.activeRange;
      const sales = (this.data.sales || []).filter(s => this.inRangeRange(s, range));
      const valid = sales.filter(s => s.status !== 'Cancelled');
      const revenue = this.sum(valid, 'amount');
      const discount = this.sum(valid, 'discount');

      // Build printable report
      const custMap = new Map(this.data.customers.map(c => [c.id, c]));
      const prodMap = new Map(this.data.products.map(p => [p.id, p.name]));
      const topOrders = this.buildOrdersRows().slice(0, 20);

      const win = window.open('', '_blank', 'width=900,height=700');
      if (!win) { Utils.toast('Allow popups to generate report', 'error'); return; }
      const dark = document.documentElement.getAttribute('data-theme') !== 'light';
      const bodyBg = dark ? '#0d0f16' : '#f1f4fa';
      const txt = dark ? '#e8eaf0' : '#131a2e';
      const muted = dark ? '#9aa1b4' : '#4c5568';
      const border = dark ? '#2a3140' : '#dde3ef';
      win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>PulseSales Report</title>
      <style>
        body{font-family:'Segoe UI',Inter,Arial,sans-serif;background:${bodyBg};color:${txt};margin:0;padding:34px}
        .wrap{max-width:820px;margin:0 auto}
        h1{margin:0;font-size:22px}.badge{display:inline-block;padding:3px 9px;border-radius:12px;font-size:11px;background:rgba(99,102,241,.15);color:#6366f1;margin-bottom:18px}
        .cards{display:flex;gap:14px;flex-wrap:wrap;margin:20px 0}
        .c{flex:1;min-width:150px;background:${dark?'#171b26':'#fff'};border:1px solid ${border};border-radius:12px;padding:15px}
        .c .l{font-size:11px;color:${muted}} .c .v{font-size:20px;font-weight:800;margin-top:4px}
        h2{font-size:15px;margin:26px 0 10px}
        table{width:100%;border-collapse:collapse;font-size:12px;background:${dark?'#171b26':'#fff'}}
        th,td{text-align:left;padding:9px 11px;border-bottom:1px solid ${border}}
        th{color:${muted};font-size:10.5px;text-transform:uppercase}
        .foot{margin-top:26px;color:${muted};font-size:11px;text-align:center}
      </style></head><body><div class="wrap">
        <h1>📊 PulseSales — Sales Report</h1>
        <span class="badge">Generated ${new Date().toLocaleString()}</span>
        <p style="color:${muted};font-size:13px;margin:4px 0 0">Period: <b>${range.label}</b> (${range.start} → ${range.end})</p>
        <div class="cards">
          <div class="c"><div class="l">Total Revenue</div><div class="v">${Utils.currency(revenue)}</div></div>
          <div class="c"><div class="l">Total Orders</div><div class="v">${sales.length}</div></div>
          <div class="c"><div class="l">Total Discount</div><div class="v">${Utils.currency(discount)}</div></div>
          <div class="c"><div class="l">Avg Order Value</div><div class="v">${Utils.currency(valid.length?Math.round(revenue/valid.length):0)}</div></div>
        </div>
        <h2>Top 20 Orders</h2>
        <table><thead><tr><th>ID</th><th>Customer</th><th>Product</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody>
        ${topOrders.map(s=>`<tr><td>#${s.id}</td><td>${custMap.get(s.customerId)?.name||''}</td><td>${prodMap.get(s.productId)||''}</td><td>${Utils.currency(s.amount)}</td><td>${s.status}</td><td>${Utils.formatDate(s.date)}</td></tr>`).join('')}
        </tbody></table>
        <div class="foot">PulseSales Analytics · Built with HTML, CSS & Vanilla JS</div>
      </div></body></html>`);
      win.document.close();
      setTimeout(() => { win.focus(); try { win.print(); } catch (e) {} }, 400);
      Utils.toast('PDF report opened in new window', 'info');
    },

    /* ========== BIND EVENTS ========== */
    bindStatic() {
      // Range pills
      document.getElementById('rangeWrap').addEventListener('click', e => {
        const btn = e.target.closest('[data-range]');
        if (!btn) return;
        document.querySelectorAll('#rangeWrap button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        Filters.state.range = btn.dataset.range;
        this.ordersPage = this.customersPage = this.productsPage = 1;
        this.applyRangeRefresh();
      });

      // Global search
      const globalSearch = document.getElementById('globalSearch');
      globalSearch.addEventListener('input', Utils.debounce(() => {
        const q = globalSearch.value.trim();
        Filters.state.globalQuery = q;
        document.getElementById('searchWrap').classList.toggle('searching', !!q);
        Filters.state.orderQuery = Filters.state.customerQuery = Filters.state.productQuery = q;
        this.ordersPage = this.customersPage = this.productsPage = 1;
        this.reRenderTables();
      }, 200));

      document.getElementById('clearSearch').addEventListener('click', () => {
        globalSearch.value = '';
        Filters.state.globalQuery = '';
        Filters.state.orderQuery = Filters.state.customerQuery = Filters.state.productQuery = '';
        document.getElementById('searchWrap').classList.remove('searching');
        this.ordersPage = this.customersPage = this.productsPage = 1;
        this.reRenderTables();
      });

      // Orders filters
      document.getElementById('orderSearch').addEventListener('input', Utils.debounce(() => {
        Filters.state.orderQuery = document.getElementById('orderSearch').value.trim();
        this.ordersPage = 1;
        this.renderOrdersTable();
      }, 200));
      document.getElementById('orderStatusFilter').addEventListener('change', e => {
        Filters.state.orderStatus = e.target.value;
        this.ordersPage = 1;
        this.renderOrdersTable();
      });

      // Customer search
      document.getElementById('customerSearch').addEventListener('input', Utils.debounce(() => {
        Filters.state.customerQuery = document.getElementById('customerSearch').value.trim();
        this.customersPage = 1;
        this.renderCustomersTable();
      }, 200));

      // Product search + category
      document.getElementById('productSearch').addEventListener('input', Utils.debounce(() => {
        Filters.state.productQuery = document.getElementById('productSearch').value.trim();
        this.productsPage = 1;
        this.renderProductsTable();
      }, 200));
      document.getElementById('productCategoryFilter').addEventListener('change', e => {
        Filters.state.productCategory = e.target.value;
        this.productsPage = 1;
        this.renderProductsTable();
      });

      // Theme
      document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());

      // Refresh
      document.getElementById('refreshBtn').addEventListener('click', async () => {
        const btn = document.getElementById('refreshBtn');
        btn.classList.add('spin');
        await this.loadData();
        this.afterLoad();
        this.applyRangeRefresh();
        setTimeout(() => btn.classList.remove('spin'), 500);
        Utils.toast('Data refreshed', 'success');
      });

      // Sidebar
      const sbToggle = document.getElementById('sidebarToggle');
      const sbClose = document.getElementById('sidebarClose');
      sbToggle.addEventListener('click', () => document.body.classList.add('sb-open'));
      sbClose.addEventListener('click', () => document.body.classList.remove('sb-open'));
      document.addEventListener('click', e => {
        if (!document.getElementById('sidebar').contains(e.target) && document.body.classList.contains('sb-open')) {
          document.body.classList.remove('sb-open');
        }
      });

      // Sidebar nav active + smooth scroll
      document.querySelectorAll('.side-nav a').forEach(a => {
        a.addEventListener('click', e => {
          e.preventDefault();
          document.querySelectorAll('.side-nav a').forEach(x => x.classList.remove('active'));
          a.classList.add('active');
          const target = a.getAttribute('href');
          if (target && target.startsWith('#')) {
            const el = document.querySelector(target);
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
          document.body.classList.remove('sb-open');
        });
      });

      // Notifications
      document.getElementById('notifBtn').addEventListener('click', () => {
        const pending = this.data.sales ? this.data.sales.filter(s => s.status === 'Pending').length : 0;
        Utils.toast(`${pending} orders are currently pending`, 'info');
      });

      // User menu
      document.getElementById('userMenu').addEventListener('click', () => {
        const menu = confirm('Sign out of PulseSales?');
        if (menu) {
          PulseSalesAuth.signOut().finally(() => {
            sessionStorage.removeItem('pulsesales_user');
            window.location.href = './index.html';
          });
        }
      });

      // Exports
      document.getElementById('exportCsvBtn').addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        this.exportCSV();
      });
      document.getElementById('pdfReportBtn').addEventListener('click', () => this.pdfReport());
    }
  };

  // pct helper (used in template inline)
  function pct(part, total) { return total ? Math.round((part / total) * 100) : 0; }

  // Expose init on window for retry button
  window.PulseSales = {
    init: () => App.init.call(App)
  };

  document.addEventListener('DOMContentLoaded', () => {
    // If Chart.js didn't load, show error
    if (typeof Chart === 'undefined') {
      App.showError('Chart.js failed to load from CDN. Check your internet connection.');
    }
    App.init();
  });
})();
