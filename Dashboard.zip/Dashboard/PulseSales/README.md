# PulseSales — Enterprise Sales Analytics Dashboard

A modern SaaS-style sales analytics dashboard built with **only** HTML5, CSS3 and Vanilla JavaScript (ES6+). All data lives in local JSON files — no backend, no framework, no build step.

> Design inspiration: Stripe Dashboard · Linear · Vercel Analytics · Shopify Admin

---

## ✨ Features

- **Premium dark SaaS UI** with glassmorphism cards, gradient accents, ambient blobs and smooth animations
- **Light/dark mode** toggle (persisted in `localStorage`)
- **14 KPI cards** fully calculated from JSON data
- **5 interactive charts** (Chart.js via CDN):
  - Revenue Trend (line) — daily vs monthly
  - Sales by Category (bar)
  - Order Status (doughnut)
  - Top 10 Products (horizontal bar)
  - Customer Growth (area)
- **Date-range filters**: Today / Last 7 days / Last 30 days / This Month / This Year — updating KPIs, charts & tables
- **Dynamic tables** with search, sorting, pagination and status/category filters:
  - Orders, Customers, Products
- **Global search** across orders, customers & products
- **Export CSV** (Sales / Customers / Products)
- **PDF Report** generation via browser print
- **Animated counters**, loading skeletons, empty states & error handling
- **Supabase Auth** login, signup, session persistence, logout and password reset

---

## 📁 Project Structure

```
PulseSales/
│── index.html              # Login page
│── dashboard.html          # Main dashboard
├── css/
│   ├── style.css           # Base + auth theme
│   └── dashboard.css       # Dashboard layout & components
├── js/
│   ├── app.js              # Login/auth logic
│   ├── dashboard.js        # Data loading, KPIs, tables, bindings
│   ├── charts.js           # Chart.js creation & updates
│   ├── filters.js          # Date/search/status filtering
│   └── utils.js            # Currency, dates, helpers
├── data/
│   ├── sales.json          # 500+ sales records
│   ├── customers.json      # 100 customers
│   ├── products.json       # 50 products
│   └── users.json          # Login credentials
└── assets/
    └── images/             # SVG logo, favicon, avatar
```

---

## 🚀 Getting Started

Because the dashboard uses `fetch()` to load local JSON files, you **must** run it over HTTP (fetch does not work on the `file://` protocol in most browsers).

### Option A — VS Code Live Server (recommended)

1. Open this folder in VS Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` → **Open with Live Server**.

### Option B — Python

```bash
cd PulseSales
python -m http.server 5500
# then open http://localhost:5500
```

### Option C — Node.js

```bash
cd PulseSales
npx http-server .
```

---

## 🔑 Authentication

Create an account from the login screen or use an account already configured in Supabase Auth.

---

## 🗂 Sample Data

- **`sales.json`** — 508 records spanning Aug 2025 → Aug 2026 with order status, payment, region & profit
- **`customers.json`** — 100 customers across 10 Indian cities
- **`products.json`** — 50 products across 10 categories
- **`users.json`** — 3 login users

---

## 🧠 Architecture

| Module | Responsibility |
|--------|----------------|
| `dashboard.js` | Loads JSON, computes metrics, renders KPIs, tables, binds all events |
| `charts.js` | Creates and updates all Chart.js instances (theme-aware) |
| `filters.js` | Date-range, search & status filtering logic |
| `utils.js` | Currency, date, number formatting + calculation helpers |

All KPIs, chart series and table metrics are **computed at runtime** from the JSON files — nothing is hardcoded.

---

© 2026 PulseSales Analytics.

